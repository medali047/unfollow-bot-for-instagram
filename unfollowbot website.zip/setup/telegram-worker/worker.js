export default {
  async fetch(req, env) {
    if (req.method !== 'POST') return new Response('ok');
    let data = {};
    try { data = await req.json(); } catch {}
    const text =
`🛒 Checkout event
Type: ${data.type || '-'}
Plan: ${data.plan || '-'}
Page: ${data.page || '-'}
Link: ${data.href || '-'}
Time: ${data.ts || new Date().toISOString()}`;

    await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ chat_id: env.TELEGRAM_CHAT_ID, text })
    });

    return new Response('ok');
  }
};