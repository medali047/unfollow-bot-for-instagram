# Telegram Beacon Relay (Cloudflare Workers)

This small Worker forwards client beacons to your Telegram bot **without exposing your bot token**.

## 1) Deploy
- Go to Cloudflare → **Workers** → Create → paste `worker.js`.
- In **Settings → Variables/Secrets**, add:
  - `TELEGRAM_BOT_TOKEN` = (your bot token)
  - `TELEGRAM_CHAT_ID` = 8026359579   # channel/user chat id

Or with `wrangler`:
```bash
wrangler secret put TELEGRAM_BOT_TOKEN
# paste: 8377132099:AAF-MYAaaQbXTbkqUbs2wkEJnKg5yaE28A0
wrangler secret put TELEGRAM_CHAT_ID
# paste: 8026359579
wrangler deploy
```

## 2) Route
Map the Worker to a route like:
- **Custom domain**: `https://tg-relay.nexadev.store/tg`
- or default: `https://<your-subdomain>.workers.dev/tg`

## 3) Website config
We already inserted a meta tag with your relay URL on product pages & success page:
```html
<meta name="tg-webhook" content="https://tg-relay.nexadev.store/tg">
```
If you deploy under a different URL, edit that `content` value in:
- `product/professional.html`
- `product/agency.html`
- `product/success.html`
